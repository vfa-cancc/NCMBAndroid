function saveData(req, res) {
  // POSTのデータを取得
  var field1 = req.body.field1;
  var field2 = req.body.field2;

  // ヘッダーのデータを取得
  var username = req.get("username");
  var password = req.get("password");
  
  var NCMB = require('ncmb');
  var ncmb = new NCMB('0730e01abce99ac3d5400690cb658a25f79e8f0bac8895dd67283e9b98077d1e', 'd4175a28a524d55c47057f6f77b47c0c654842521b94488442867c82deb83dac');

  if ( username != "admin" || password != "123456" ) {
    res.status(501);
    res.send("Authentication fail!");
    
  }

  // データを保存する
  var Item = ncmb.DataStore('Item');
  var item = new Item();
  item.set("field1", field1)
      .set("field2", field2)
      .save()
      .then(function(item){
        // 成功
        res.send("POST data successfully!");
      })
      .catch(function(err){
        // 失敗
        res.send("Error: " + err);
      });
}

module.exports = saveData;